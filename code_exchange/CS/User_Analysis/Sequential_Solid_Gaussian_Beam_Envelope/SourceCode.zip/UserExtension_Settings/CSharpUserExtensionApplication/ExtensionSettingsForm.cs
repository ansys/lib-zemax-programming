﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpUserExtensionApplication
{
    public partial class ExtensionSettingsForm : Form
    {        
        private int _WaveNumber;
        private double _M2factor;
        private double _S1toW;
        private double _waist;
                

        public ExtensionSettingsForm()
        {
            InitializeComponent();

            // This loads up the settings form, and populates the settings with the specified values
            // Put all intialization scripts in here (including loading setting values from previous run)
            // Create a connection to OpticStudio in order to get information from 'Program.cs'
            ZOSAPI.ZOSAPI_Connection TheConnection = new ZOSAPI.ZOSAPI_Connection();
            ZOSAPI.IZOSAPI_Application TheApplication = TheConnection.ConnectToApplication();
            ZOSAPI.IOpticalSystem TheSystem = TheApplication.PrimarySystem;

            this.AcceptButton = button_OK;
            this.CancelButton = button_Cancel;


            // Generate a list of possible surfaces (i.e. not ignored) for the Object setting combo-box
            // There must be at least 1 valid surface, otherwise Program.c would have errored out                        
            for (int i = 1; i <= TheApplication.PrimarySystem.SystemData.Wavelengths.NumberOfWavelengths; i++)
            {                
                cb_WaveNum.Items.Add(i);
            }
               

            // Set some initial values for settings data (same intial values as in Program.cs)            
            int initial_WaveNumber = 0;
            double initial_M2factor = 1;
            double initial_S1toW = 0;
            double initial_waist = 0.005;                        

            // Populate the settings form with the set values            
            cb_WaveNum.SelectedIndex = initial_WaveNumber;
            tb_waist.Text = Convert.ToString(initial_waist);
            tb_M2.Text = Convert.ToString(initial_M2factor);
            tb_s1tow.Text = Convert.ToString(initial_S1toW);                       
                        
        }

        private void ExtensionSettingsForm_Load(object sender, EventArgs e)
        {

        }

        
        private void B_OK_Click(object sender, EventArgs e)
        {
            // This is run when the user hits "OK"    
            _WaveNumber = (int)cb_WaveNum.SelectedIndex;
            _M2factor = Convert.ToDouble(tb_M2.Text);
            _S1toW = Convert.ToDouble(tb_s1tow.Text);
            _waist = Convert.ToDouble(tb_waist.Text);
            
            DialogResult = DialogResult.OK;
            Close();

        }

        private void B_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        // Get & set surface number              
        public int WaveNumber
        {
            get { return _WaveNumber; }
            set { _WaveNumber = value; }
        }

        public double M2factor
        {
            get { return _M2factor; }
            set { _M2factor = value; }
        }

        public double S1toW
        {
            get { return _S1toW; }
            set { _S1toW = value; }
        }

        public double waist
        {
            get { return _waist; }
            set { _waist = value; }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ExtensionSettingsForm_Load_1(object sender, EventArgs e)
        {

        }

        private void cb_SurfNum_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
