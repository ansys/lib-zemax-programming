using System;
using System.Windows.Forms;
using ZOSAPI;
using ZOSAPI.Analysis;
using ZOSAPI.Analysis.Data;
using ZOSAPI.Analysis.Settings.Surface;
using ZOSAPI.Common;
using ZOSAPI.Editors.LDE;
using System.Collections.Generic;
using ZOSAPI.Editors.NCE;

namespace CSharpUserExtensionApplication
{
    class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]



        static void Main(string[] args)
        {
            // Find the installed version of OpticStudio
            bool isInitialized = ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize();
            // Note -- uncomment the following line to use a custom initialization path
            //bool isInitialized = ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(@"C:\Program Files\OpticStudio\");
            if (isInitialized)
            {
                LogInfo("Found OpticStudio at: " + ZOSAPI_NetHelper.ZOSAPI_Initializer.GetZemaxDirectory());
            }
            else
            {
                HandleError("Failed to locate OpticStudio!");
                return;
            }

            BeginUserExtension();
        }

        static void BeginUserExtension()
        {
            // Create the initial connection class
            ZOSAPI_Connection TheConnection = new ZOSAPI_Connection();

            // Attempt to connect to the existing OpticStudio instance
            IZOSAPI_Application TheApplication = null;
            try
            {
                TheApplication = TheConnection.ConnectToApplication(); // this will throw an exception if not launched from OpticStudio
            }
            catch (Exception ex)
            {
                HandleError(ex.Message);
                return;
            }
            if (TheApplication == null)
            {
                HandleError("An unknown connection error occurred!");
                return;
            }
            if (TheApplication.Mode != ZOSAPI_Mode.Plugin)
            {
                HandleError("User plugin was started in the wrong mode: expected Plugin, found " + TheApplication.Mode.ToString());
                return;
            }

            // Check the connection status
            if (!TheApplication.IsValidLicenseForAPI)
            {
                HandleError("Failed to connect to OpticStudio: " + TheApplication.LicenseStatus);
                return;
            }

            // That doesn�t affect the undo behavior, but can make extensions run significantly faster
            TheApplication.ShowChangesInUI = false;

            TheApplication.ProgressMessage = "Running Extension...";

            IOpticalSystem TheSystem = TheApplication.PrimarySystem;
            //change the update mode in Preferences to EditorsOnly prior to running the extension
            LensUpdateMode currentUpdateMode = TheSystem.UpdateMode;
            TheSystem.UpdateMode = LensUpdateMode.EditorsOnly;


            if (!TheApplication.TerminateRequested) // This will be 'true' if the user clicks on the Cancel button
            {

                // Add your custom code here...

                //Get input from the user through the WinAppFrom
                ExtensionSettingsForm SettingsForm = ShowUserExtensionSettings(TheApplication);

                if (SettingsForm.DialogResult == DialogResult.OK)
                {

                    //need to check that settings have changed

                    int user_wavenumber = SettingsForm.WaveNumber;
                    double user_waist = SettingsForm.waist;
                    double user_S1toW = SettingsForm.S1toW;
                    double user_M2factor = SettingsForm.M2factor;
                    bool FreeformSuccess = true;

                    string comment2 = "Wave=" + user_wavenumber.ToString() + " W=" + user_waist.ToString() + " S1toW=" + user_S1toW.ToString() + " M2=" + user_M2factor.ToString();

                    //If any Delete non-sequential component in the sequential editor                    
                    DeleteNonSequentialComponent(TheApplication, comment2);

                    //Create two vector arrays: one containing the beam size and one containing the beam position
                    //Fill two lists
                    //ListBeamSize will contain the list of the beam sizes
                    //ListBeamPosition will contain the list of the global z positions where the beam sizes are calculated
                    List<double> ListBeamSize = new List<double>();
                    List<double> ListBeamPosition = new List<double>();
                    CreateGaussianBeamArray(TheApplication, SettingsForm.WaveNumber, SettingsForm.waist, SettingsForm.S1toW, SettingsForm.M2factor, ListBeamSize, ListBeamPosition);
                    double[] ArrayBeamPosition = ListBeamPosition.ToArray();
                    double[] ArrayBeamSize = ListBeamSize.ToArray();

                    //Add a non-sequential component in the sequential editor
                    int NbSurfaces = TheApplication.PrimarySystem.LDE.NumberOfSurfaces;
                    AddNonSequentialComponent(TheApplication, NbSurfaces, comment2);

                    //Add a FreeformZ volume in the Non-sequential editor to model the envelope of the paraxial gaussian beam
                    FreeformSuccess = CreateFreeformZGaussianBeam(TheApplication, NbSurfaces, ArrayBeamSize, ArrayBeamPosition);

                    //If the Freeform Z volume fails, add a series of Cylinder Volumes in the Non-sequential editor to model the envelope of the paraxial gaussian beam
                    if (FreeformSuccess == false)
                    {
                        CreateCylinderVolumeGaussianBeam(TheApplication, NbSurfaces, ArrayBeamSize, ArrayBeamPosition);
                    }

                    //Display the changes made to the file
                    //Open a Non-sequential editor
                    //Open a Shaded Model
                    TheApplication.ShowChangesInUI = true;
                    TheSystem.NCE.ShowNCE();
                    TheSystem.Analyses.New_Analysis(ZOSAPI.Analysis.AnalysisIDM.ShadedModel);
                }
                else if (SettingsForm.DialogResult == DialogResult.Cancel)
                {
                    TheApplication.ProgressMessage = "No settings!";
                    System.Threading.Thread.Sleep(1000);
                }

            }

            //restore the update mode            
            TheSystem.UpdateMode = currentUpdateMode;

            //Conversion Done         
            TheApplication.ProgressMessage = "Done.";// Please press Terminate!";

            /*
            do
            {

            } while (!TheApplication.TerminateRequested);
            */

            // Clean up
            FinishUserExtension(TheApplication);
        }


        static void FinishUserExtension(IZOSAPI_Application TheApplication)
        {
            // Note - OpticStudio will stay in User Extension mode until this application exits
            if (TheApplication != null)
            {
                TheApplication.ProgressMessage = "Completed";
            }
        }

        static void LogInfo(string message)
        {
            // TODO - add custom logging
            Console.WriteLine(message);
        }

        static void HandleError(string errorMessage)
        {
            // TODO - add custom error handling
            throw new Exception(errorMessage);
        }


        static ExtensionSettingsForm ShowUserExtensionSettings(IZOSAPI_Application TheApplication)
        {
            IOpticalSystem TheSystem = TheApplication.PrimarySystem;

            // TODO - retrieve the settings specific to your analysis here

            // This will show a form to modify your settings (currently blank)...
            ExtensionSettingsForm SettingsForm = new ExtensionSettingsForm();

            // Add your custom code here, and to the SettingsForm...
            Application.Run(SettingsForm);

            // return the settings form
            return SettingsForm;
        }

        static void CreateGaussianBeamArray(IZOSAPI_Application TheApplication, int user_wavenumber, double user_waist, double user_S1toW, double user_M2factor, List<double> ListBeamSize, List<double> ListBeamPosition)
        {

            int NbSurfaces = TheApplication.PrimarySystem.LDE.NumberOfSurfaces;
            double BeamSize = 0;
            double BeamPosition = 0;
            double WaistPosition = 0;
            double WaistSize = 0;
            double surface_thickness = 0;
            int current_surface = 1;

            int i = 1;
            do
            {
                //GBPS Surf Wave UseX W0 S1toW M2 factor 
                current_surface = i;

                surface_thickness = TheApplication.PrimarySystem.LDE.GetSurfaceAt(i).Thickness;

                BeamSize = TheApplication.PrimarySystem.MFE.GetOperandValue(ZOSAPI.Editors.MFE.MeritOperandType.GBPS, current_surface, user_wavenumber, 0, user_waist, user_S1toW, user_M2factor, 0, 0);
                WaistPosition = TheApplication.PrimarySystem.MFE.GetOperandValue(ZOSAPI.Editors.MFE.MeritOperandType.GBPP, current_surface, user_wavenumber, 0, user_waist, user_S1toW, user_M2factor, 0, 0);
                WaistSize = TheApplication.PrimarySystem.MFE.GetOperandValue(ZOSAPI.Editors.MFE.MeritOperandType.GBPW, current_surface, user_wavenumber, 0, user_waist, user_S1toW, user_M2factor, 0, 0);

                ListBeamSize.Add(BeamSize);
                ListBeamPosition.Add(BeamPosition);

                // i>1 and i< NbSurfaces: image plane
                // position_waist < 0: waist is after the surface
                if (i > 1 && i < NbSurfaces)
                {
                    if ((WaistPosition) < 0 && (Math.Abs(WaistPosition) < surface_thickness))
                    {
                        TheApplication.ProgressMessage = "Waist between surfaces...";
                        ListBeamSize.Add(WaistSize);
                        ListBeamPosition.Add(BeamPosition - WaistPosition);
                    }
                }

                BeamPosition = BeamPosition + surface_thickness;
                i++;

            } while ((i < NbSurfaces));
            //TheSystem.LDE.NumberOfSurfaces counts also Surface 0                                

        }

        static void DeleteNonSequentialComponent(IZOSAPI_Application TheApplication, string comment2)
        {

            string NscSurfaceComment = "Paraxial Gaussian Display";

            //If a Non-Sequential Component with the comment "Paraxial Gaussian Display" already exists, we delete it
            for (int k = 1; k < TheApplication.PrimarySystem.LDE.NumberOfSurfaces; k++)
            {
                if (TheApplication.PrimarySystem.LDE.GetSurfaceAt(k).Comment == NscSurfaceComment)
                {
                    TheApplication.PrimarySystem.LDE.DeleteRowAt(k);
                    TheApplication.PrimarySystem.LDE.DeleteRowAt(k);
                }
            }            
        }

            static void AddNonSequentialComponent(IZOSAPI_Application TheApplication, int NbSurfaces, string comment2)
        {

            string NscSurfaceComment = "Paraxial Gaussian Display";

            //If a Non-Sequential Component with the comment "Paraxial Gaussian Display" already exists, we delete it
            for (int k = 1; k < TheApplication.PrimarySystem.LDE.NumberOfSurfaces; k++)
            {
                if (TheApplication.PrimarySystem.LDE.GetSurfaceAt(k).Comment == NscSurfaceComment)
                {
                    TheApplication.PrimarySystem.LDE.DeleteRowAt(k);
                    TheApplication.PrimarySystem.LDE.DeleteRowAt(k);
                }
            }
            NbSurfaces = TheApplication.PrimarySystem.LDE.NumberOfSurfaces;

            //In the editor we are defining a non-sequential component                
            //Add 2 surfaces : entrance and exit port
            //Add comments on the surfaces                               

            TheApplication.PrimarySystem.LDE.InsertNewSurfaceAt(NbSurfaces - 1);
            TheApplication.PrimarySystem.LDE.InsertNewSurfaceAt(NbSurfaces - 1);
            ILDERow SurfNSC = TheApplication.PrimarySystem.LDE.GetSurfaceAt(NbSurfaces - 1);
            ILDERow SurfNSC2 = TheApplication.PrimarySystem.LDE.GetSurfaceAt(NbSurfaces);
            ISurfaceTypeSettings SurfNSC_Settings = SurfNSC.GetSurfaceTypeSettings(SurfaceType.NonSequential);
            SurfNSC.ChangeType(SurfNSC_Settings);
            SurfNSC.Comment = NscSurfaceComment;
            SurfNSC2.Comment = comment2;            
        }

        private static bool CreateFreeformZGaussianBeam(IZOSAPI_Application TheApplication, int NbSurfaces, double[] ArrayBeamSize, double[] ArrayBeamPosition)
        {
            bool success = true;
            double SurfNSC_Zvalue = TheApplication.PrimarySystem.MFE.GetOperandValue(ZOSAPI.Editors.MFE.MeritOperandType.GLCZ, NbSurfaces - 1, 0, 0, 0, 0, 0, 0, 0);            

            //In non-sequential: define freeform Z  
            INCERow FreeformObject = TheApplication.PrimarySystem.NCE.GetObjectAt(1);
            //Rays ignore the Freeform object
            FreeformObject.TypeData.RaysIgnoreObject = ZOSAPI.Editors.NCE.RaysIgnoreObjectType.Always;
            //Set the opacity of the beam to 50%                                
            FreeformObject.DrawData.Opacity = ZOSAPI.Common.ZemaxOpacity.P50;

            FreeformObject.ZPosition = -SurfNSC_Zvalue;
            IObjectTypeSettings FreeformObject_Settings = FreeformObject.GetObjectTypeSettings(ObjectType.FreeformZ);
            FreeformObject.ChangeType(FreeformObject_Settings);
            IObjectFreeformZ FreeformObject_Data = FreeformObject.ObjectData as IObjectFreeformZ;
            //Number of points      
            FreeformObject_Data.NumberOfPoints = ArrayBeamSize.Length;
                          
            int j = 1;
            do
            {
                FreeformObject.GetCellAt(11 + 2 * j).Value = ArrayBeamPosition[j - 1].ToString();
                FreeformObject.GetCellAt(11 + 2 * j + 1).Value = ArrayBeamSize[j - 1].ToString();
                j = j + 1;
            } while (j <= ArrayBeamSize.Length);

            TheApplication.PrimarySystem.GetCurrentStatus();

            //Check if the Freeform Z creates an error          
            //If Freeform Z creates an error we switch to a cone definition            
            if (TheApplication.PrimarySystem.GetCurrentStatus().Length!=0)
            {
                success = false;
                //Delete the Freeform Z object
                TheApplication.PrimarySystem.NCE.RemoveObjectAt(1);
                TheApplication.ProgressMessage = "Freeform Z failed!";
                System.Threading.Thread.Sleep(500);
                return success;
            }

            return success;
        }

        static void CreateCylinderVolumeGaussianBeam(IZOSAPI_Application TheApplication, int NbSurfaces, double[] ArrayBeamSize, double[] ArrayBeamPosition)
        {
            double SurfNSC_Zvalue = TheApplication.PrimarySystem.MFE.GetOperandValue(ZOSAPI.Editors.MFE.MeritOperandType.GLCZ, NbSurfaces - 1, 0, 0, 0, 0, 0, 0, 0);

            //In non-sequential: Create a list of Cylinder Volume objects            
            int j = 1;
            do
            {
                INCERow Object = TheApplication.PrimarySystem.NCE.InsertNewObjectAt(j);
                Object.ZPosition = -SurfNSC_Zvalue + ArrayBeamPosition[j-1];
                IObjectTypeSettings CylinderVolume_Settings = Object.GetObjectTypeSettings(ObjectType.CylinderVolume);
                Object.ChangeType(CylinderVolume_Settings);
                IObjectCylinderVolume Object_Data = Object.ObjectData as IObjectCylinderVolume;            
                Object_Data.FrontR = ArrayBeamSize[j - 1];
                Object_Data.BackR = ArrayBeamSize[j];
                Object_Data.ZLength = ArrayBeamPosition[j]- ArrayBeamPosition[j-1];

                //Set the opacity of the beam to 50%                                
                Object.DrawData.Opacity = ZOSAPI.Common.ZemaxOpacity.P50;
                //Rays ignore the Freeform object
                Object.TypeData.RaysIgnoreObject = ZOSAPI.Editors.NCE.RaysIgnoreObjectType.Always;

                j = j + 1;
            } while (j < ArrayBeamSize.Length);                                             

        }
                
    }
}
